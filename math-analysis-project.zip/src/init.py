# modules/0001/src/init.py
import sys
import os

# Автоматически добавляем папку src в sys.path для надежного импорта main.py
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

import main as m
import calccore as cc


def initialize():
    # Регистрируем все математические операции и классы кнопок в ядре
    for f in m.functions:
        cc.core_instance.add_function(name=f["name"], func_class=f["func"])

    # Регистрируем константы e, pi и gamma
    for c in m.constants:
        cc.core_instance.add_constant(name=c["name"], value=c["val"])

    print("-> Модуль Матанализа (0001) успешно инициализирован.")
