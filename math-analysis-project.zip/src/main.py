# modules/0001/src/main.py
from sympy import sympify, limit, diff, integrate, Symbol, oo

class LimitOperation:
    def __init__(self): self.args = []
    def add_value(self, value): self.args.append(value)
    def exec(self):
        if len(self.args) < 2: return "Ошибка: нужно 2 аргумента (функция, точка)"
        try:
            x = Symbol('x')
            expr = sympify(self.args[0])
            target = oo if self.args[1] == "oo" else sympify(self.args[1])
            res = limit(expr, x, target)
            return str(res)
        except Exception as e: return f"Ошибка lim: {e}"

class DerivativeOperation:
    def __init__(self): self.args = []
    def add_value(self, value): self.args.append(value)
    def exec(self):
        if len(self.args) < 1: return "Ошибка: введите функцию"
        try:
            x = Symbol('x')
            expr = sympify(self.args[0])
            res = diff(expr, x)
            return str(res)
        except Exception as e: return f"Ошибка производной: {e}"

class DifferentialOperation:
    def __init__(self): self.args = []
    def add_value(self, value): self.args.append(value)
    def exec(self):
        if len(self.args) < 1: return "Ошибка: введите функцию"
        try:
            x = Symbol('x')
            expr = sympify(self.args[0])
            res = diff(expr, x)
            return f"({res})*dx" # Дифференциал — это производная, умноженная на dx
        except Exception as e: return f"Ошибка дифференциала: {e}"

class IntegralOperation:
    def __init__(self): self.args = []
    def add_value(self, value): self.args.append(value)
    def exec(self):
        if len(self.args) < 1: return "Ошибка: введите функцию"
        try:
            x = Symbol('x')
            expr = sympify(self.args[0])
            # Если ввели 1 аргумент -> Неопределенный интеграл
            if len(self.args) == 1:
                res = integrate(expr, x)
                return f"{res} + C"
            # Если ввели 3 аргумента -> Определенный интеграл, например: integrate(x^2, 0, 5)
            elif len(self.args) == 3:
                a = oo if self.args[1] == "oo" else sympify(self.args[1])
                b = oo if self.args[2] == "oo" else sympify(self.args[2])
                res = integrate(expr, (x, a, b))
                return str(res)
            return "Ошибка: нужно 1 или 3 аргумента"
        except Exception as e: return f"Ошибка интеграла: {e}"

# Класс-заглушка для кнопки "x", чтобы она просто вставляла символ
class VariableX:
    def __init__(self): pass
    def add_value(self, v): pass
    def exec(self): return "x"

# Регистрируем функции и расставляем кнопки по координатам
functions = [
    {"name": "lim", "func": LimitOperation, "pos": {"row": 0, "col": 4}},
    {"name": "diff", "func": DerivativeOperation, "pos": {"row": 2, "col": 4}},
    {"name": "diff_d", "func": DifferentialOperation, "pos": {"row": 3, "col": 4}},
    {"name": "int", "func": IntegralOperation, "pos": {"row": 4, "col": 4}},
    {"name": "x", "func": VariableX, "pos": {"row": 1, "col": 4}} # Встанет в 5-й ряд вместо части кнопки '='
]

constants = [
    {"name": "e", "val": 2.7182818284},
    {"name": "pi", "val": 3.1415926535},
    {"name": "gamma", "val": 0.5772156649}
]
