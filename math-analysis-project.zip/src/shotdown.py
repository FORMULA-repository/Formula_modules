# modules/0001/src/shotdown.py
import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

import main as m
import calccore as cc


def shutdown():
    # Удаляем функции из реестра ядра
    for f in m.functions:
        cc.core_instance.remove_function(name=f["name"])

    # Удаляем константы из реестра ядра
    for c in m.constants:
        cc.core_instance.remove_constant(name=c["name"])

    print("-> Модуль Матанализа (0001) успешно отключен.")
