# modules/0002/src/init.py
import sys, os
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

import main as m
import calccore as cc

def initialize():
    for f in m.functions:
        cc.core_instance.add_function(name=f["name"], func_class=f["func"])
