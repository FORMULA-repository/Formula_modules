# modules/0002/src/main.py
import calccore as cc


class SigmaSumOperation:
    def __init__(self):
        self.args = []

    def add_value(self, value):
        self.args.append(value)

    def exec(self):
        if len(self.args) < 3:
            return "Ошибка: нужно 3 аргумента (выражение, старт, финиш)"
        try:
            expr = self.args[0]
            start, end = int(self.args[1]), int(self.args[2])

            total_sum = 0
            for i in range(start, end + 1):
                # Жестко заменяем 'x' на текущее число счетчика
                current_expr = expr.replace('x', str(i))
                step_res = cc.core_instance.evaluate(current_expr)
                total_sum += float(step_res)

            return str(total_sum)
        except Exception as e:
            return f"Ошибка sigma: {e}"


class PiProductOperation:
    def __init__(self):
        self.args = []

    def add_value(self, value):
        self.args.append(value)

    def exec(self):
        if len(self.args) < 3:
            return "Ошибка: нужно 3 аргумента (выражение, старт, финиш)"
        try:
            expr = self.args[0]
            start, end = int(self.args[1]), int(self.args[2])

            total_prod = 1
            for i in range(start, end + 1):
                # Жестко заменяем 'x' на текущее число счетчика
                current_expr = expr.replace('x', str(i))
                step_res = cc.core_instance.evaluate(current_expr)
                total_prod *= float(step_res)

            return str(total_prod)
        except Exception as e:
            return f"Ошибка prod: {e}"


# Выводим кнопки во второй ряд модулей, чтобы не расширять сетку приложения вбок
functions = [
    {"name": "sigma", "func": SigmaSumOperation, "pos": {"row": 0, "col": 5}},
    {"name": "prod", "func": PiProductOperation, "pos": {"row": 1, "col": 5}}
]

constants = []
